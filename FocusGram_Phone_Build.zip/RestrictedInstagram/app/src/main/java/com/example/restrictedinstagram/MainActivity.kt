package com.example.restrictedinstagram

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.*
import androidx.compose.ui.tooling.preview.Preview

private val Pink = Color(0xFFE1306C)
private val Purple = Color(0xFF833AB4)

data class Chat(val name: String, val preview: String, val unread: Int = 0)
data class Notice(val title: String, val detail: String)

private val chats = listOf(
    Chat("Rahul", "Sent you a reel", 2),
    Chat("Aman", "Bro 😂", 0),
    Chat("Priya", "See this story", 1),
    Chat("Medical Group", "New message", 4)
)

private val notices = listOf(
    Notice("Rahul liked your message", "2 min ago"),
    Notice("Aman sent you a reel", "18 min ago"),
    Notice("Priya mentioned you in a story", "1 h ago"),
    Notice("3 new followers", "Today")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FocusGramApp() }
    }
}

@Composable
fun FocusGramApp() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = lightColorScheme(primary = Pink)) {
        NavHost(navController = nav, startDestination = "login") {
            composable("login") { LoginScreen { nav.navigate("home") { popUpTo("login") { inclusive = true } } } }
            composable("home") { MainShell(nav, "home") }
            composable("messages") { MainShell(nav, "messages") }
            composable("notifications") { MainShell(nav, "notifications") }
            composable("profile") { MainShell(nav, "profile") }
            composable("stories") { StoriesScreen { nav.popBackStack() } }
            composable("chat/{name}") { back ->
                ChatScreen(back.arguments?.getString("name") ?: "Friend") { nav.navigate("sharedReel") }
            }
            composable("sharedReel") { SharedReelScreen { nav.popBackStack() } }
            composable("settings") { SettingsScreen { nav.popBackStack() } }
        }
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("FocusGram", fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Instagram-style access without the endless Reels feed.",
            color = Color.Gray)
        Spacer(Modifier.height(40.dp))
        Button(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp)
        ) { Text("Continue with Instagram") }
        Spacer(Modifier.height(18.dp))
        Text("Prototype mode: Instagram data is mocked.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun MainShell(nav: NavController, current: String) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FocusGram", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton({ nav.navigate("notifications") }) {
                        Icon(Icons.Default.Notifications, "Notifications")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavItem(Icons.Default.Home, "Home", current == "home") { nav.navigate("home") }
                NavItem(Icons.Default.Email, "Chats", current == "messages") { nav.navigate("messages") }
                NavItem(Icons.Default.AddCircle, "Stories", false) { nav.navigate("stories") }
                NavItem(Icons.Default.Notifications, "Alerts", current == "notifications") { nav.navigate("notifications") }
                NavItem(Icons.Default.Person, "Profile", current == "profile") { nav.navigate("profile") }
            }
        }
    ) { pad ->
        when (current) {
            "home" -> HomeScreen(Modifier.padding(pad), nav)
            "messages" -> MessagesScreen(Modifier.padding(pad), nav)
            "notifications" -> NotificationsScreen(Modifier.padding(pad))
            "profile" -> ProfileScreen(Modifier.padding(pad), nav)
        }
    }
}

@Composable
fun RowScope.NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, click: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = click, icon = { Icon(icon, label) }, label = { Text(label) })
}

@Composable
fun HomeScreen(modifier: Modifier, nav: NavController) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Stories", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("You", "Rahul", "Aman", "Priya", "Neha").forEach {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(58.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
                        Text(it.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Text(it, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Your feed is intentionally limited", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text("You can open stories, messages and reels your friends send you. There is no infinite Reels feed.")
                Spacer(Modifier.height(14.dp))
                OutlinedButton({ nav.navigate("messages") }) { Text("Open messages") }
            }
        }
    }
}

@Composable
fun MessagesScreen(modifier: Modifier, nav: NavController) {
    Column(modifier.fillMaxSize()) {
        Text("Messages", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        OutlinedTextField(value = "", onValueChange = {}, enabled = false,
            placeholder = { Text("Search") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        LazyColumn {
            items(chats) { chat ->
                ListItem(
                    headlineContent = { Text(chat.name, fontWeight = FontWeight.SemiBold) },
                    supportingContent = { Text(chat.preview) },
                    leadingContent = {
                        Box(Modifier.size(48.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
                            Text(chat.name.take(1), color = Color.White)
                        }
                    },
                    trailingContent = { if (chat.unread > 0) Badge { Text("${chat.unread}") } },
                    modifier = Modifier.clickable { nav.navigate("chat/${chat.name}") }
                )
                HorizontalDivider()
            }
        }
    }
}

@Composable
fun ChatScreen(name: String, openReel: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text(name) }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            Spacer(Modifier.weight(1f))
            Text("Hey 👋", modifier = Modifier.padding(8.dp))
            Text("Check this out!", modifier = Modifier.align(Alignment.End).padding(8.dp))
            Card(
                Modifier.fillMaxWidth().height(240.dp).clickable { openReel() },
                shape = RoundedCornerShape(18.dp)
            ) {
                Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(56.dp))
                        Text("Friend sent you a Reel", color = Color.White)
                        Text("Tap to watch — no next-Reel scrolling", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(value = "", onValueChange = {}, enabled = false,
                placeholder = { Text("Message...") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun SharedReelScreen(back: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Shared Reel") }, navigationIcon = {
        IconButton(back) { Icon(Icons.Default.ArrowBack, "Back") }
    }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).background(Color.Black), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(90.dp))
            Text("REEL VIDEO", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text("Shared by your friend", color = Color.LightGray)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().padding(22.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Text("♥", color = Color.White, fontSize = 28.sp)
                Text("💬", color = Color.White, fontSize = 24.sp)
                Text("↗", color = Color.White, fontSize = 28.sp)
            }
        }
    }
}

@Composable
fun StoriesScreen(back: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Stories") }, navigationIcon = {
        IconButton(back) { Icon(Icons.Default.ArrowBack, "Back") }
    }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).background(Color.Black), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            Text("STORY", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("Friend's story", color = Color.LightGray)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("‹", color = Color.White, fontSize = 45.sp)
                Text("›", color = Color.White, fontSize = 45.sp)
            }
        }
    }
}

@Composable
fun NotificationsScreen(modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize()) {
        item { Text("Notifications", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp)) }
        items(notices) { n ->
            ListItem(
                headlineContent = { Text(n.title) },
                supportingContent = { Text(n.detail) },
                leadingContent = {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Pink), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, null, tint = Color.White)
                    }
                }
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier, nav: NavController) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(80.dp).clip(CircleShape).background(Purple), contentAlignment = Alignment.Center) {
                Text("N", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(18.dp))
            Column {
                Text("@your_account", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Connected Instagram account", color = Color.Gray)
            }
        }
        Spacer(Modifier.height(24.dp))
        Button({ }, Modifier.fillMaxWidth()) { Text("Edit profile") }
        OutlinedButton({ nav.navigate("settings") }, Modifier.fillMaxWidth()) { Text("Settings") }
    }
}

@Composable
fun SettingsScreen(back: () -> Unit) {
    var restricted by remember { mutableStateOf(true) }
    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = {
        IconButton(back) { Icon(Icons.Default.ArrowBack, "Back") }
    }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            ListItem(headlineContent = { Text("Reels restriction") },
                supportingContent = { Text("Disable infinite scrolling") },
                trailingContent = { Switch(checked = restricted, onCheckedChange = { restricted = it }) })
            HorizontalDivider()
            ListItem(headlineContent = { Text("Shared Reels only") },
                supportingContent = { Text("Open Reels only from chats") },
                trailingContent = { Text(if (restricted) "ON" else "OFF", color = Pink, fontWeight = FontWeight.Bold) })
            HorizontalDivider()
            ListItem(headlineContent = { Text("Account") }, supportingContent = { Text("Instagram connection") })
            ListItem(headlineContent = { Text("Logout") })
        }
    }
}

@Preview
@Composable
fun PreviewLogin() {
    MaterialTheme { LoginScreen {} }
}
