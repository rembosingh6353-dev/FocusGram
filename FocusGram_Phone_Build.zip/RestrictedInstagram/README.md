# FocusGram — Restricted Instagram Client Prototype

This is a Kotlin + Jetpack Compose Android Studio prototype based on the requested concept.

## Current prototype
- Login screen (prototype/mock)
- Home
- Stories UI
- Messages list
- Individual chat
- Shared Reel viewer
- Notifications
- Profile
- Settings
- Reels restriction toggle
- No infinite Reel feed
- Shared Reels can be opened from a chat

## Important
The Instagram account connection in this prototype is intentionally mocked.

Do NOT collect an Instagram password inside this app and do NOT scrape Instagram private endpoints.
For production, authentication and any Instagram data access must use Meta/Instagram's currently supported official authentication/API flows and only the permissions/data they allow.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `RestrictedInstagram` folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android emulator or device.

The UI is intentionally simple in v0.1 so the navigation and restricted-Reels behavior can be tested first.
